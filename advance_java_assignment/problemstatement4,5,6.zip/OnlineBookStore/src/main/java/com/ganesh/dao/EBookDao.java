package com.ganesh.dao;


import java.sql.Timestamp;
import java.util.List;

import com.ganesh.model.Book;
import com.ganesh.model.User;

public interface EBookDao {
    
	int registerUsers(String name , String address ,String email , String userName, String password , Timestamp registerDate);
	
	User validateLogin(String username , String password);
	
	List<Book> getAllAvailableBooks();
	
	Book getBookById(Long bookid);
	
	int addOrder(Long bookId, String custName , String phoneno, String address, Timestamp orderDate, int quantity);
	
	boolean verifyUser(String email , String userName);
	
	int resetPassword(String email , String username ,String newPassword);
	
}


