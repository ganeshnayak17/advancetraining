package com.ganesh.regularexpression;

public class RegularExpression
{
	public static void main(String[] args) {
		
		
		String txt= (" 26  +  95  -  (  043  /  52  ) ");
		String[] w=txt.split("\\s");
		
		for(String w1:w){  
			System.out.println(w1);
		}
	}
}
