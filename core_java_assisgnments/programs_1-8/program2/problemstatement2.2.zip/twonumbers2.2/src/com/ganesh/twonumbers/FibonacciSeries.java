package com.ganesh.twonumbers;
import java.util.Scanner;
class FibonacciSeries
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the limit +2 or greater than 2");
		int seriesLimit=sc.nextInt();
		if(seriesLimit>=2)
		{
			int a=1;
			int b=3;
			System.out.print(a+" ");
			System.out.print(b+" ");
			for(int i=1;i<=seriesLimit-2;i++)
			{
				int c=a+b;
				System.out.print(c+" ");
				a=b;
				b=c;
			}
		}
			else
			{
				System.out.println("limit is less than 2");
			}
	
	}
}

