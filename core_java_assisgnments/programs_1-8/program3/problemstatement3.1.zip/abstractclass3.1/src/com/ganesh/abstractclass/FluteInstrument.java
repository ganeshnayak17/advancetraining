package com.ganesh.abstractclass;

public class FluteInstrument extends Instrument {

	@Override
	public void play() {
		System.out.println("Flute is playing  toot toot toot toot");

	}

}
