package com.ganesh.abstractclass;

public class GuitarInstrument extends Instrument {

	@Override
	public void play() {
		System.out.println("Guitar is playing  tin  tin  tin............");

	}

}