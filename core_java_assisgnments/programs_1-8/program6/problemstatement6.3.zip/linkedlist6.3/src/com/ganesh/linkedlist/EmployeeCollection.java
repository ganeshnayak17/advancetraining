package com.ganesh.linkedlist;
import java.util.Vector;
public class EmployeeCollection
{
	public static void main(String[] args) {
		Vector<Employees> v = addInput();
		display(v);
		}

	private static Vector<Employees> addInput() {
		Employees e1=new Employees (101,"ram", "shanker");
		Employees e2=new Employees (102,"benny", "monu");
		Employees e3=new Employees (103,"siva", "shanu");
		Vector<Employees> v=new Vector<Employees>();
		v.add(e1);
		v.add(e2);
		v.add(e3);
		return v;
	
		}

	private static void display(Vector<Employees> v) {
		for(Employees e:v)
		{
			System.out.println(e.getEmpid()+"\t"+e.getEname()+"\t"+e.getAddress());
		}
		
	}

	
}