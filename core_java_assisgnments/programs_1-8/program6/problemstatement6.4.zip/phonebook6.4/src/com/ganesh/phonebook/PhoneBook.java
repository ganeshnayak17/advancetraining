package com.ganesh.phonebook;

import java.io.*;
import java.sql.*;
import java.util.*;

public class PhoneBook {
	public static String help_msg = "Choose Options : \n A. Add contact \n S. Search \n Q. Exit :";

	public static void main(String[] args) {
		System.out.println("\n*** Welcome to MyPhone Book ***\n");
		System.out.println("--------------------------------------");
		Scanner s = new Scanner(System.in);
		for (;;) {
			System.out.print("[Main Menu] \n" + help_msg + "\n:");
			String command = s.nextLine().trim();

			if (command.equalsIgnoreCase("A")) {
				System.out.print("Type in contact details in the format: Firstname,Lastname,PhoneNO:\n:\n");

			} else if (command.equalsIgnoreCase("S")) {
				System.out.print("Type in the Firstname you are searching for :\n:\n");

			} else if (command.equalsIgnoreCase("Q")) {
				System.out.println("Good Bye....");
				System.exit(0);
			} else {
				System.out.print("Unknown command ! Try again \n:");
			}

		}

	}

}
